<?php
UserService::Logout();
UserService::Redirect(CONTEXT_PATH.'/login')
?>